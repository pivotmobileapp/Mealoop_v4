(function ($) {
    $.mobiscroll.i18n['en-GB'] = $.mobiscroll.i18n['en-UK'] = {
        dateFormat: 'dd/mm/yy',
        dateOrder: 'ddmmy',
        timeFormat: 'HH:ii',
        timeWheels: 'HHii'
    };
})(jQuery);