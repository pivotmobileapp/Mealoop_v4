
var krms_config ={	
	'ApiUrl' : "http://mealoop.com/mobileapp/api",
	'DialogDefaultTitle' : "mealoop",
	'pushNotificationSenderid' : "1039967975155",
	'facebookAppId' : "1785452871717052",
	'APIHasKey' : "fed7b441b349bae8f146711fbd215e90"
};