  /*      $("#mobile").intlTelInput({
            autoPlaceholder: false,
            defaultCountry: 'AM',
            autoHideDialCode: true,
            nationalMode: false,
            autoFormat: false,
            utilsScript: "lib/intel/lib/libphonenumber/build/utils.js"
        });*/